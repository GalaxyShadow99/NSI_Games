# 8-bit pixel border

A Pen created on CodePen.io. Original URL: [https://codepen.io/robdimarzo/pen/eYWmxKr](https://codepen.io/robdimarzo/pen/eYWmxKr).

